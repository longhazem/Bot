# main.py
import os
import nextcord
from keep_alive import keep_alive

intents = nextcord.Intents.default()
client = nextcord.Client(intents=intents)

GUILD_ID = os.getenv("GUILD_ID")  # Server ID nếu muốn sync lệnh nhanh
TOKEN = os.getenv("TOKEN")

@client.slash_command(name="hello", description="Chào bot 👋")
async def hello(interaction: nextcord.Interaction):
    await interaction.response.send_message(f"👋 Xin chào {interaction.user.display_name}!", ephemeral=True)

@client.event
async def on_ready():
    print(f"✅ Đã đăng nhập thành công: {client.user}")
    await client.change_presence(
        status=nextcord.Status.online,
        activity=nextcord.Game("/hello")
    )

keep_alive()
client.run(TOKEN)
